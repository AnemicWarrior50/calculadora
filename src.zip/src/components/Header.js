function Header(){
    return (
        <div className="card-header">
            ¿Cuanto dinero necesitas?
        </div>
    );
}

export default Header;

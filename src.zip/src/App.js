/* import logo from './logo.svg'; */
import { useState } from 'react';
import './App.css';
import Header from './components/Header';
import Button from './components/Button';
import { totalPagar } from './helpers'

function App() {
  const [cantidad, setCantidad] = useState(10000);
  const [meses, setMeses] = useState(6);
  const [total, setTotal] = useState( totalPagar(cantidad, meses) );

  const MIN = 0;
  const MAX = 20000;
  const STEP = 100;
  
  function handleChange(e){
    setCantidad(parseInt(e.target.value));
    setTotal( totalPagar(cantidad, meses) );
  }

  function handleClickDecremento(){
    const valor = cantidad - STEP;
    if ( valor < MIN ){
      alert("Cantidad no valida");
      return;
    }
    setCantidad(valor);
    setTotal( totalPagar(cantidad, meses) );
  }

  function handleClickIncremento(){
    const valor = cantidad + STEP;
    if ( valor > MAX ){
      alert("Cantidad no valida");
      return;
    }
    setCantidad(valor);
    setTotal( totalPagar(cantidad, meses) );
  }

  return (
    <div className='container'>
      <div className='row justify-content-center'>
        <div className='col-4'>
          <div className="card">
          <Header />
          <div className="card-body">
            <div className='row justify-content-between'>
              <div className='col-4'>
                <Button 
                  operador = '-'
                  fn = { handleClickDecremento }
                />
              </div>
              <div className='col-4 text-right'> 
                <Button 
                  operador = '+'
                  fn = { handleClickIncremento }
                />
              </div>
            </div>
            <input 
              type='range'
              className='form-control'
              min = { MIN }
              max = { MAX }
              step = { STEP }
              value = { cantidad }
              onChange = { handleChange }
            />
            <div className='text-center'>
              ${ cantidad }
            </div>
            <div>
              <select 
                className='form-control'
                onChange = { e => setMeses( parseInt(e.target.value) ) }
              >
                <option value='6'>6 Meses</option>
                <option value='12'>12 Meses</option>
                <option value='24'>24 Meses</option>
              </select>
            </div>
            <div>
              <h2>Resumen</h2>
              <p>Meses: { meses }</p>
              <p>Total a pagar: ${ total }</p>
              <p>Mensualidad: </p>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;

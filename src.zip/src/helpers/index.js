function totalPagar(cantidad, meses){
    // Si es de 0 a 5,000 le agregamos el 50% de interes
    // Si es de 5,000 a 10,000 le agregamos el 40% de interes
    // Si es de 10,000 a 15,000 le agregamos el 30% de interes
    // Si es de 15,000 a 20,000 le agregamos el 20% de interes

    // 6 meses 10%
    // 12 meses 20%
    // 24 meses 30%
    
    let total = 0;

    if ( cantidad <= 5000 ){
        total += cantidad + (cantidad * .5);
    } else if ( cantidad <= 10000 ) {
        total += cantidad + (cantidad * .4);
    } else if ( cantidad <= 15000 ) {
        total += cantidad + (cantidad * .3);
    } else if ( cantidad <= 20000 ) {
        total += cantidad + (cantidad * .2);
    } 

    console.log(total);

    if ( meses === 6 ){
        total += total * .1;
    } else if ( meses === 12 ) {
        total += total * .2;
    } else if ( meses === 24 ) {
        total += total * .3;
    }

    console.log(total);

    return total;
}

export{
    totalPagar
}